//
//  ViewController.swift
//  testSDKIOS
//
//  Created by Become on 26/02/21.
//

import UIKit
import BecomeDigitalV

class ViewController: UIViewController {
    @IBOutlet var userId: UITextField!
    @IBOutlet var token: UITextField!
    @IBOutlet var keyboardHeightLayoutConstraint: NSLayoutConstraint?
    @IBOutlet var contractId: UITextField!
    
    var responseIV = ResponseIV()
    var userID = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.keyboardNotification(notification:)),
                                               name: UIResponder.keyboardWillChangeFrameNotification,
                                               object: nil)
        
        BDIVCallBack.sharedInstance.delegate = self
        btnSecont.isHidden = true
    }
    
    @IBAction func startAction(_ sender: Any) {
        if(!(token.text?.isEmpty ?? true)){
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "es_ES") // date user identification
            dateFormatter.dateFormat = "yyyyMMddHHmmssSSS"
            userID = userId.text!.isEmpty ? dateFormatter.string(from: Date()) : userId.text!
            let bdivConfig = BDIVConfig(token:token.text!,
                                        contractId:  (contractId.text!.isEmpty ? "" : contractId.text)!,
                                        userId: userID,
                                        ItFirstTransaction: true)
            BDIVCallBack.sharedInstance.register(bdivConfig: bdivConfig)
        }else{
            token.becomeFirstResponder()
        }
    }
    
    @IBAction func secondAction(_ sender: Any) {
        lblResponse.text = "Enviando segunda petición..."
        let bdivConfig = BDIVConfig(token: token.text!,
                                    contractId:  (contractId.text!.isEmpty ? "" : contractId.text)!,
                                    userId: userID,
                                    ItFirstTransaction: false,
                                    imgData: (responseIV.fullFronImage?.pngData())!)
        BDIVCallBack.sharedInstance.register(bdivConfig: bdivConfig)
    }
    
    @IBOutlet var lblResponse: UILabel!
    
    @IBOutlet var imgFullFront: UIImageView!
    @IBOutlet var imgFullBack: UIImageView!
    @IBOutlet var imgFront: UIImageView!
    @IBOutlet var imgBack: UIImageView!
    @IBOutlet var btnSecont: UIButton!
    
    
    @objc func keyboardNotification(notification: NSNotification) {
        guard let userInfo = notification.userInfo else { return }
        
        let endFrame = (userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
        let endFrameY = endFrame?.origin.y ?? 0
        let duration:TimeInterval = (userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? NSNumber)?.doubleValue ?? 0
        let animationCurveRawNSN = userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as? NSNumber
        let animationCurveRaw = animationCurveRawNSN?.uintValue ?? UIView.AnimationOptions.curveEaseInOut.rawValue
        let animationCurve:UIView.AnimationOptions = UIView.AnimationOptions(rawValue: animationCurveRaw)
        
        if endFrameY >= UIScreen.main.bounds.size.height {
            self.keyboardHeightLayoutConstraint?.constant = 10
        } else {
            self.keyboardHeightLayoutConstraint?.constant = (endFrame?.size.height ?? 0.0) + 10
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action:  #selector (self.tapHideKeyBoard(_:)))
        self.view.addGestureRecognizer(tapGesture)
        UIView.animate(
            withDuration: duration,
            delay: TimeInterval(0),
            options: animationCurve,
            animations: { self.view.layoutIfNeeded() },
            completion: nil)
    }
    
    
    @objc func tapHideKeyBoard(_ sender:UITapGestureRecognizer){
        view.endEditing(true)
    }
    
}

extension ViewController: BDIVDelegate{
    func BDIVResponseSuccess(bdivResult: AnyObject) {
        responseIV = bdivResult as! ResponseIV
        print(String(describing: responseIV))
        
        if(responseIV.IsFirstTransaction){
            btnSecont.isHidden = false
            lblResponse.text = String(describing: responseIV)
            self.imgFront.image = responseIV.frontImage
            self.imgBack.image = responseIV.backImage
            self.imgFullBack.image = responseIV.fullBackImage
            self.imgFullFront.image = responseIV.fullFronImage
        }else{
            lblResponse.text = String(describing: responseIV.documentValidation)
        }
    }
    
    func BDIVResponseError(error: String) {
        print(error)
        lblResponse.text = error
    }
}

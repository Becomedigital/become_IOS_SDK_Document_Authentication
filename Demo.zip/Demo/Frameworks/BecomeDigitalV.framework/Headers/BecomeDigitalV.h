//
//  BecomeDigitalV.h
//  BecomeDigitalV
//
//  Created by Nelson Peña on 25/02/21.
//

#import <Foundation/Foundation.h>

//! Project version number for BecomeDigitalV.
FOUNDATION_EXPORT double BecomeDigitalVVersionNumber;

//! Project version string for BecomeDigitalV.
FOUNDATION_EXPORT const unsigned char BecomeDigitalVVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BecomeDigitalV/PublicHeader.h>


